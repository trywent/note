/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <stdarg.h>
#include <dirent.h>
#include <limits.h>
#include <errno.h>
#include <sys/poll.h>

#include <cutils/misc.h>
#include <cutils/sockets.h>
#include <cutils/multiuser.h>

#define _REALLY_INCLUDE_SYS__SYSTEM_PROPERTIES_H_
#include <sys/_system_properties.h>

#include <sys/socket.h>
#include <sys/un.h>
#include <sys/select.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/mman.h>
#include <private/android_filesystem_config.h>

#include <selinux/selinux.h>
#include <selinux/label.h>

#include "property_service.h"
#include "init.h"
#include "util.h"
#include "log.h"

#define PERSISTENT_PROPERTY_DIR  "/data/property"
#define FYTMIPI					(1<<1)
#define FYTWIFI					(1<<2)
#define FYT512M					(1<<3)


static int persistent_properties_loaded = 0;
static int property_area_inited = 0;

static int property_set_fd = -1;

typedef struct {
    size_t size;
    int fd;
} workspace;

static int init_workspace(workspace *w, size_t size)
{
    void *data;
    int fd = open(PROP_FILENAME, O_RDONLY | O_NOFOLLOW);
    if (fd < 0)
        return -1;

    w->size = size;
    w->fd = fd;
    return 0;
}

static workspace pa_workspace;

static int init_property_area(void)
{
    if (property_area_inited)
        return -1;

    if(__system_property_area_init())
        return -1;

    if(init_workspace(&pa_workspace, 0))
        return -1;

    fcntl(pa_workspace.fd, F_SETFD, FD_CLOEXEC);

    property_area_inited = 1;
    return 0;
}

static int check_mac_perms(const char *name, char *sctx)
{
    if (is_selinux_enabled() <= 0)
        return 1;

    char *tctx = NULL;
    const char *class = "property_service";
    const char *perm = "set";
    int result = 0;

    if (!sctx)
        goto err;

    if (!sehandle_prop)
        goto err;

    if (selabel_lookup(sehandle_prop, &tctx, name, 1) != 0)
        goto err;

    if (selinux_check_access(sctx, tctx, class, perm, (void*) name) == 0)
        result = 1;

    freecon(tctx);
 err:
    return result;
}

static int check_control_mac_perms(const char *name, char *sctx)
{
    /*
     *  Create a name prefix out of ctl.<service name>
     *  The new prefix allows the use of the existing
     *  property service backend labeling while avoiding
     *  mislabels based on true property prefixes.
     */
    char ctl_name[PROP_VALUE_MAX+4];
    int ret = snprintf(ctl_name, sizeof(ctl_name), "ctl.%s", name);

    if (ret < 0 || (size_t) ret >= sizeof(ctl_name))
        return 0;

    return check_mac_perms(ctl_name, sctx);
}

/*
 * Checks permissions for setting system properties.
 * Returns 1 if uid allowed, 0 otherwise.
 */
static int check_perms(const char *name, char *sctx)
{
    int i;
    unsigned int app_id;

    //add by yhx to let TestCase set this property for CTS
    if(strcmp("sys.cts.capture",name)==0)
    {
        return 1;
    }

    if(!strncmp(name, "ro.", 3))
        name +=3;

    return check_mac_perms(name, sctx);
}

int __property_get(const char *name, char *value)
{
    return __system_property_get(name, value);
}

static void write_persistent_property(const char *name, const char *value)
{
    char tempPath[PATH_MAX];
    char path[PATH_MAX];
    int fd;

    snprintf(tempPath, sizeof(tempPath), "%s/.temp.XXXXXX", PERSISTENT_PROPERTY_DIR);
    fd = mkstemp(tempPath);
    if (fd < 0) {
        ERROR("Unable to write persistent property to temp file %s errno: %d\n", tempPath, errno);
        return;
    }
    write(fd, value, strlen(value));
    fsync(fd);
    close(fd);

    snprintf(path, sizeof(path), "%s/%s", PERSISTENT_PROPERTY_DIR, name);
    if (rename(tempPath, path)) {
        unlink(tempPath);
        ERROR("Unable to rename persistent property file %s to %s\n", tempPath, path);
    }
}

static bool is_legal_property_name(const char* name, size_t namelen)
{
    size_t i;
    if (namelen >= PROP_NAME_MAX) return false;
    if (namelen < 1) return false;
    if (name[0] == '.') return false;
    if (name[namelen - 1] == '.') return false;

    /* Only allow alphanumeric, plus '.', '-', or '_' */
    /* Don't allow ".." to appear in a property name */
    for (i = 0; i < namelen; i++) {
        if (name[i] == '.') {
            // i=0 is guaranteed to never have a dot. See above.
            if (name[i-1] == '.') return false;
            continue;
        }
        if (name[i] == '_' || name[i] == '-') continue;
        if (name[i] >= 'a' && name[i] <= 'z') continue;
        if (name[i] >= 'A' && name[i] <= 'Z') continue;
        if (name[i] >= '0' && name[i] <= '9') continue;
        return false;
    }

    return true;
}

int property_set(const char *name, const char *value)
{
    prop_info *pi;
    int ret;

    size_t namelen = strlen(name);
    size_t valuelen = strlen(value);

    if (!is_legal_property_name(name, namelen)) return -1;
    if (valuelen >= PROP_VALUE_MAX) return -1;

    pi = (prop_info*) __system_property_find(name);

    if(pi != 0) {
        /* ro.* properties may NEVER be modified once set */
        if(!strncmp(name, "ro.", 3)) return -1;

        __system_property_update(pi, value, valuelen);
    } else {
        ret = __system_property_add(name, namelen, value, valuelen);
        if (ret < 0) {
            ERROR("Failed to set '%s'='%s'\n", name, value);
            return ret;
        }
    }
    /* If name starts with "net." treat as a DNS property. */
    if (strncmp("net.", name, strlen("net.")) == 0)  {
        if (strcmp("net.change", name) == 0) {
            return 0;
        }
       /*
        * The 'net.change' property is a special property used track when any
        * 'net.*' property name is updated. It is _ONLY_ updated here. Its value
        * contains the last updated 'net.*' property.
        */
        property_set("net.change", name);
    } else if (persistent_properties_loaded &&
            strncmp("persist.", name, strlen("persist.")) == 0) {
        /*
         * Don't write properties to disk until after we have read all default properties
         * to prevent them from being overwritten by default values.
         */
        write_persistent_property(name, value);
    } else if (strcmp("selinux.reload_policy", name) == 0 &&
               strcmp("1", value) == 0) {
        selinux_reload_policy();
    }
    property_changed(name, value);
    return 0;
}

void handle_property_set_fd()
{
    prop_msg msg;
    int s;
    int r;
    int res;
    struct ucred cr;
    struct sockaddr_un addr;
    socklen_t addr_size = sizeof(addr);
    socklen_t cr_size = sizeof(cr);
    char * source_ctx = NULL;
    struct pollfd ufds[1];
    const int timeout_ms = 2 * 1000;  /* Default 2 sec timeout for caller to send property. */
    int nr;

    if ((s = accept(property_set_fd, (struct sockaddr *) &addr, &addr_size)) < 0) {
        return;
    }

    /* Check socket options here */
    if (getsockopt(s, SOL_SOCKET, SO_PEERCRED, &cr, &cr_size) < 0) {
        close(s);
        ERROR("Unable to receive socket options\n");
        return;
    }

    ufds[0].fd = s;
    ufds[0].events = POLLIN;
    ufds[0].revents = 0;
    nr = TEMP_FAILURE_RETRY(poll(ufds, 1, timeout_ms));
    if (nr == 0) {
        ERROR("sys_prop: timeout waiting for uid=%d to send property message.\n", cr.uid);
        close(s);
        return;
    } else if (nr < 0) {
        ERROR("sys_prop: error waiting for uid=%d to send property message. err=%d %s\n", cr.uid, errno, strerror(errno));
        close(s);
        return;
    }

    r = TEMP_FAILURE_RETRY(recv(s, &msg, sizeof(msg), MSG_DONTWAIT));
    if(r != sizeof(prop_msg)) {
        ERROR("sys_prop: mis-match msg size received: %d expected: %zu errno: %d\n",
              r, sizeof(prop_msg), errno);
        close(s);
        return;
    }

    switch(msg.cmd) {
    case PROP_MSG_SETPROP:
        msg.name[PROP_NAME_MAX-1] = 0;
        msg.value[PROP_VALUE_MAX-1] = 0;

        if (!is_legal_property_name(msg.name, strlen(msg.name))) {
            ERROR("sys_prop: illegal property name. Got: \"%s\"\n", msg.name);
            close(s);
            return;
        }

        getpeercon(s, &source_ctx);

        if(memcmp(msg.name,"ctl.",4) == 0) {
            // Keep the old close-socket-early behavior when handling
            // ctl.* properties.
            close(s);
            if (check_control_mac_perms(msg.value, source_ctx)) {
                handle_control_message((char*) msg.name + 4, (char*) msg.value);
            } else {
                ERROR("sys_prop: Unable to %s service ctl [%s] uid:%d gid:%d pid:%d\n",
                        msg.name + 4, msg.value, cr.uid, cr.gid, cr.pid);
            }
        } else {
            if (check_perms(msg.name, source_ctx)) {
                property_set((char*) msg.name, (char*) msg.value);
            } else {
                ERROR("sys_prop: permission denied uid:%d  name:%s\n",
                      cr.uid, msg.name);
            }

            // Note: bionic's property client code assumes that the
            // property server will not close the socket until *AFTER*
            // the property is written to memory.
            close(s);
        }
        freecon(source_ctx);
        break;

    default:
        close(s);
        break;
    }
}

void get_property_workspace(int *fd, int *sz)
{
    *fd = pa_workspace.fd;
    *sz = pa_workspace.size;
}

static void load_properties_from_file(const char *, const char *);

/*
 * Filter is used to decide which properties to load: NULL loads all keys,
 * "ro.foo.*" is a prefix match, and "ro.foo.bar" is an exact match.
 */
static void load_properties(char *data, const char *filter)
{
    char *key, *value, *eol, *sol, *tmp, *fn;
    size_t flen = 0;

    if (filter) {
        flen = strlen(filter);
    }

    sol = data;
    while ((eol = strchr(sol, '\n'))) {
        key = sol;
        *eol++ = 0;
        sol = eol;

        while (isspace(*key)) key++;
        if (*key == '#') continue;

        tmp = eol - 2;
        while ((tmp > key) && isspace(*tmp)) *tmp-- = 0;

        if (!strncmp(key, "import ", 7) && flen == 0) {
            fn = key + 7;
            while (isspace(*fn)) fn++;

            key = strchr(fn, ' ');
            if (key) {
                *key++ = 0;
                while (isspace(*key)) key++;
            }

            load_properties_from_file(fn, key);

        } else {
            value = strchr(key, '=');
            if (!value) continue;
            *value++ = 0;

            tmp = value - 2;
            while ((tmp > key) && isspace(*tmp)) *tmp-- = 0;

            while (isspace(*value)) value++;

            if (flen > 0) {
                if (filter[flen - 1] == '*') {
                    if (strncmp(key, filter, flen - 1)) continue;
                } else {
                    if (strcmp(key, filter)) continue;
                }
            }

            property_set(key, value);
        }
    }
}

/*
 * Filter is used to decide which properties to load: NULL loads all keys,
 * "ro.foo.*" is a prefix match, and "ro.foo.bar" is an exact match.
 */
static void load_properties_from_file(const char *fn, const char *filter)
{
    char *data;
    unsigned sz;

    data = read_file(fn, &sz);

    if(data != 0) {
        load_properties(data, filter);
        free(data);
    }
}

static void load_persistent_properties()
{
    DIR* dir = opendir(PERSISTENT_PROPERTY_DIR);
    int dir_fd;
    struct dirent*  entry;
    char value[PROP_VALUE_MAX];
    int fd, length;
    struct stat sb;

    if (dir) { 
        dir_fd = dirfd(dir);
        while ((entry = readdir(dir)) != NULL) {
            if (strncmp("persist.", entry->d_name, strlen("persist.")))
                continue;
#if HAVE_DIRENT_D_TYPE
            if (entry->d_type != DT_REG)
                continue;
#endif
            /* open the file and read the property value */
            fd = openat(dir_fd, entry->d_name, O_RDONLY | O_NOFOLLOW);
            if (fd < 0) {
                ERROR("Unable to open persistent property file \"%s\" errno: %d\n",
                      entry->d_name, errno);
                continue;
            }
            if (fstat(fd, &sb) < 0) {
                ERROR("fstat on property file \"%s\" failed errno: %d\n", entry->d_name, errno);
                close(fd);
                continue;
            }

            // File must not be accessible to others, be owned by root/root, and
            // not be a hard link to any other file.
            if (((sb.st_mode & (S_IRWXG | S_IRWXO)) != 0)
                    || (sb.st_uid != 0)
                    || (sb.st_gid != 0)
                    || (sb.st_nlink != 1)) {
                ERROR("skipping insecure property file %s (uid=%u gid=%u nlink=%d mode=%o)\n",
                      entry->d_name, (unsigned int)sb.st_uid, (unsigned int)sb.st_gid,
                      sb.st_nlink, sb.st_mode);
                close(fd);
                continue;
            }

            length = read(fd, value, sizeof(value) - 1);
            if (length >= 0) {
                value[length] = 0;
                property_set(entry->d_name, value);
            } else {
                ERROR("Unable to read persistent property file %s errno: %d\n",
                      entry->d_name, errno);
            }
            close(fd);
        }
        closedir(dir);
    } else {
        ERROR("Unable to open persistent property directory %s errno: %d\n", PERSISTENT_PROPERTY_DIR, errno);
    }

    persistent_properties_loaded = 1;
}

void property_init(void)
{
    init_property_area();
}

void property_load_boot_defaults(void)
{
    load_properties_from_file(PROP_PATH_RAMDISK_DEFAULT, NULL);
}

int properties_inited(void)
{
    return property_area_inited;
}

static void load_override_properties() {
#ifdef ALLOW_LOCAL_PROP_OVERRIDE
    char debuggable[PROP_VALUE_MAX];
    int ret;

    ret = property_get("ro.debuggable", debuggable);
    if (ret && (strcmp(debuggable, "1") == 0)) {
        load_properties_from_file(PROP_PATH_LOCAL_OVERRIDE, NULL);
    }
#endif /* ALLOW_LOCAL_PROP_OVERRIDE */
}


/* When booting an encrypted system, /data is not mounted when the
 * property service is started, so any properties stored there are
 * not loaded.  Vold triggers init to load these properties once it
 * has mounted /data.
 */
void load_persist_props(void)
{
    load_override_properties();
    /* Read persistent properties after all default values have been loaded. */
    load_persistent_properties();
}

void setsubPlatform(void);
void fyt_set_backcar_type(void);
void fyt_set_backup_mirror(void);
void setDefualtdate();

void load_all_props(void)
{
	load_properties_from_file("/system/app/fyt_build.prop",NULL);

    load_properties_from_file(PROP_PATH_SYSTEM_BUILD, NULL);
    load_properties_from_file(PROP_PATH_SYSTEM_DEFAULT, NULL);
    load_properties_from_file(PROP_PATH_VENDOR_BUILD, NULL);
    load_properties_from_file(PROP_PATH_FACTORY, "ro.*");

	load_properties_from_file("/system/app/fyt.prop",NULL);
	load_properties_from_file("/system/app/config.txt",NULL);

    load_override_properties();

    /* Read persistent properties after all default values have been loaded. */
    load_persistent_properties();
	setsubPlatform();
#if SETTING_MIRROR   
	fyt_set_backup_mirror();
#endif
	fyt_set_backcar_type();
	setDefualtdate();
}

#include "../toolbox/date.c"
void setDefualtdate()
{
	char val[PROP_VALUE_MAX]={0};
	int count = 0;
//	property_get("ro.build.version.incremental",val);
	property_get("ro.build.date.utc",val);
	if(val[0] != 0) {
		char *cmd[3] = {"date",val, NULL};
		date_main(2, cmd);
	}
}

void fyt_set_property(void);
void start_property_service(void)
{
    int fd;

    fd = create_socket(PROP_SERVICE_NAME, SOCK_STREAM, 0666, 0, 0, NULL);
    if(fd < 0) return;
    fcntl(fd, F_SETFD, FD_CLOEXEC);
    fcntl(fd, F_SETFL, O_NONBLOCK);

    listen(fd, 8);
    property_set_fd = fd;
    fyt_set_property();
}

int get_property_set_fd()
{
    return property_set_fd;
}

#if 1
#include "../../../kernel/include/linux/sqlinfo.h"
#define SQL_DEVICE  "/dev/block/platform/soc0/e0000000.noc/by-name/ImcPartID033"
static PSQL_INFO mmap_sql_device(int *fd,int flags)
{
    *fd = open(SQL_DEVICE,O_RDWR); 
    if (*fd <= 0) {
        printf("[%s][%d]: open %s fail",__FUNCTION__,__LINE__,SQL_DEVICE);
        return NULL;
    }
    PSQL_INFO psql_info = (PSQL_INFO)mmap(NULL, sizeof(SQL_INFO), flags /*PROT_READ | PROT_WRITE*/, MAP_SHARED, *fd, 0);
    if (psql_info == MAP_FAILED) {
        printf("[%s][%d]: mmap %s fail",__FUNCTION__,__LINE__,SQL_DEVICE);
        close(*fd);
        return NULL;
    }
    return psql_info;
}

static int munmap_sql_device(int *fd,PSQL_INFO psql_info,bool flush) 
{
    int ret = -1;
	if (NULL != psql_info) {
        if(flush)
            msync((void*)psql_info, sizeof(SQL_INFO), MS_SYNC);
        ret = munmap((void*)psql_info,sizeof(SQL_INFO));
    }    
    if (*fd > 0) 
        close(*fd);
    return ret; 
}
void setSqlbootMode(void){
   int fd;
   int ret;
   char buf[4];
   char val[PROP_VALUE_MAX]={0};

   fd = open("/sys/fytver/sqlbtmode",O_RDWR);
   if (fd<0) {
      ERROR("open file failed.\n");
      return ;
   }
   ret = read(fd,val,3);
   close(fd);
   
   property_set("sys.fyt.sqlbtmode",val);
}

void setPlatform(void){
   int fd;
   int ret;
   char buf[4];
   char val[PROP_VALUE_MAX]={0};

   fd = open("/sys/fytver/platform",O_RDWR);
   if (fd<0) {
      ERROR("open file failed.\n");
      return ;
   }
   ret = read(fd,val,4);
   close(fd);
   
   property_set("sys.fyt.platform",val);
  // property_set("ro.fyt.platform",val);
}
void setsubPlatform(void){
   int fd;
   int ret;
   char buf[4];
   char val[PROP_VALUE_MAX]={0};
	char	val2[PROP_VALUE_MAX];	
	int subplatform=0;

   fd = open("/sys/fytver/subplatform",O_RDWR);
   if (fd<0) {
      ERROR("open file failed.\n");
      return ;
   }
   ret = read(fd,val,4);
   close(fd);
	
   	property_get("persist.modem.disable",val2);
	printf("setsubPlatform....%d....%s...... \n",subplatform,val);
	
	//ret = sscanf(val, "%d", subplatform);
	switch(strlen(val))
	{
	case 1:
		subplatform = val[0] - '0';
		break;
	case 2:
		subplatform = (val[0] - '0')*10 + (val[1] - '0');
		break;
	case 3:
		 subplatform = (val[0] - '0')*100 + (val[1] - '0')*10 + val[2];
		break;
	default:
		subplatform = val[0] - '0';
		break;
	}
	

	if(!strncmp(val2,"true",4))
	{
		if(subplatform &1){
			subplatform &= ~1;
			subplatform |= FYTWIFI;	
		}
	}else{
		subplatform &= ~FYTWIFI;	
	}
	sprintf(val,"%d", subplatform);
	printf("setsubPlatform....%d....%s...... \n",subplatform,val);
	
	//subplatform |= FYTWIFI;		
	//sprintf(val,"%d", subplatform);
	//property_set("sys.fyt.subplatform",val);

   property_set("sys.fyt.subplatform",val);
}
int fyt_serialno(void){
	char * path="/sys/bus/mmc/devices/mmc0:0001/cid";
	int fd;
	unsigned char buf[33];
	int i;
	
	fd =open(path,O_RDONLY);
	if(fd<0){
		printf("open file failed.\n");
		return 1;
	}

	if(read(fd,buf,32)!=32){
		printf("read file failed.\n");
		close(fd);
		return 1;	
	}
	property_set("serialno",(char*)buf);
	close(fd);
	return 0;
}

#if SETTING_MIRROR
void fyt_set_backup_mirror(void)
{
#define CAMERAHAL_DVP_IMAGE_MIRROR "sys_graphic.cam_dvp.mirror"
	int fd_sql = 0;
	PSQL_INFO psql_info = mmap_sql_device(&fd_sql,PROT_READ);
	if (psql_info != NULL) {
		property_set(CAMERAHAL_DVP_IMAGE_MIRROR, 1 == psql_info->sqlcfg.BackCarMirror?"true":"false");
		munmap_sql_device(&fd_sql,psql_info,false);
	} else {
		printf("[%s][%d]: mmap error!",__FUNCTION__,__LINE__);
	}	
}
#endif

const char * sql_ro_platform[] = {PLATFORM_STRS}; 

#define RO_PLATFORM_SIZE  (sizeof(sql_ro_platform)/sizeof(sql_ro_platform[0]))

//sys.fyt.def.bcsh    state: on/off + b:value +c:value + s:value +h:value
//sys.fyt.used.bcsh  state: on/off + b:value +c:value + s:value +h:value
#if 0
void set_sys_bcsh(PSQL_INFO psql_info)
{
	int ison=0;
	int b,c,s,h;
	char value[PROP_VALUE_MAX];
	int *p;
	b=c=s=h=0;	
	if(psql_info->gammadata[1024+64]=='b'
	   &&psql_info->gammadata[1024+64+1]=='c'
	   &&psql_info->gammadata[1024+64+2]=='s'
	   &&psql_info->gammadata[1024+64+3]=='h')
	  ison =1;

	if(ison){
		p = &psql_info->gammadata[1024+64+4];
		b = p[0];
		c = p[1];
		s = p[2];
		h=  p[3];
	}
	sprintf(value,"%d %d %d %d %d",ison,b,c,s,h);	
	property_set("sys.fyt.used.bcsh",value);
	if(psql_info->gammadata[1024+96]=='b'
	   &&psql_info->gammadata[1024+96+1]=='c'
	   &&psql_info->gammadata[1024+96+2]=='s'
	   &&psql_info->gammadata[1024+96+3]=='h')
	  ison =1;

	if(ison){
		p = &psql_info->gammadata[1024+96+4];
		b = p[0];
		c = p[1];
		s = p[2];
		h=  p[3];
	}
	sprintf(value,"%d %d %d %d %d",ison,b,c,s,h);	
	property_set("sys.fyt.def.bcsh",value);
}
#else
void set_sys_bcsh(PSQL_INFO psql_info)
{
	int ison=0;
	unsigned int b,c,s,h;
	char value[PROP_VALUE_MAX];
	unsigned char *p;
	b=c=s=h=0;	
	if(psql_info->gammadata[1024+64]=='b'
	   &&psql_info->gammadata[1024+64+1]=='c'
	   &&psql_info->gammadata[1024+64+2]=='s'
	   &&psql_info->gammadata[1024+64+3]=='h')
	  ison =1;

	if(ison){
		p = (unsigned char *)&psql_info->gammadata[1024+64+4];
		b = p[0]<<24 | p[1]<<16 | p[2]<<8 |p[3];
		c = p[4]<<24 | p[5]<<16 | p[6]<<8 |p[7];
		s = p[8]<<24 | p[9]<<16 | p[10]<<8 |p[11];
		h=  p[12]<<24 | p[13]<<16 | p[14]<<8 |p[15];
	}
	sprintf(value,"%d %d %d %d %d",ison,b,c,s,h);	
	property_set("sys.fyt.used.bcsh",value);
	if(psql_info->gammadata[1024+96]=='b'
	   &&psql_info->gammadata[1024+96+1]=='c'
	   &&psql_info->gammadata[1024+96+2]=='s'
	   &&psql_info->gammadata[1024+96+3]=='h')
	  ison =1;
	else
	ison =0;

		
	p = (unsigned char *)&psql_info->gammadata[1024+96+4];
	b = p[0]<<24 | p[1]<<16 | p[2]<<8 |p[3];
	c = p[4]<<24 | p[5]<<16 | p[6]<<8 |p[7];
	s = p[8]<<24 | p[9]<<16 | p[10]<<8 |p[11];
	h=  p[12]<<24 | p[13]<<16 | p[14]<<8 |p[15];
	
	sprintf(value,"%d %d %d %d %d",ison,b,c,s,h);	
	property_set("sys.fyt.def.bcsh",value);
}
#endif

void fyt_set_backcar_type(void)
{
    PSQL_INFO psql_info = NULL;
    int fd_sql = 0,type = 0,ret;
    bool sync = false;
    char typevalue[PROP_VALUE_MAX] = {'0',0,};
	ret = property_get("ro.fyt.usbenable",typevalue);
	if (ret>=0)
		type = atoi(typevalue);
    psql_info = mmap_sql_device(&fd_sql,PROT_READ | PROT_WRITE);

    if (psql_info != NULL) {
		/*
        if (type >= 0 ) {
            if (type != psql_info->sqlcfg.BackCarType) {
                psql_info->sqlcfg.BackCarType = type;
                sync = true;
            }
        }
		*/
		//===============================  wus aplogs
		if(psql_info->sqlcfg.m_aplogson==1)
			property_set("persist.service.apklogfs.enable", "1");
		else{
#if 0
			if(psql_info->sqlcfg.m_SqlDebugoff==SIGNATURE_OFFSQLDEBUG){
				if(psql_info->sqlcfg.m_sqlaplog!=0){
					psql_info->sqlcfg.m_sqlaplog =0;
					 sync = true;	
				}	
			}
			if(psql_info->sqlcfg.m_sqlaplog && psql_info->sqlcfg.m_sqlaplog<APLOG_AUTOOFF_PWRCNT){
							
				property_set("persist.service.apklogfs.enable", "1");
				ret = property_get("ro.fyt.sqlbtmode",typevalue);
				if(typevalue[0]==2){
					psql_info->sqlcfg.m_sqlaplog++;		
					sync = true;
				}
					
			}else{
				property_set("persist.service.apklogfs.enable", "0");
			}
#else
			property_set("persist.service.apklogfs.enable", "0");
#endif
		}
		if(SPECIAL_TCH_SIGNATURE == psql_info->ntouch_cfgs.signature){
			sprintf(typevalue,"%d",psql_info->ntouch_cfgs.have_areakey);
			property_set("ro.fyt.fixedtch.config", typevalue);
			memset(typevalue,0,PROP_VALUE_MAX);
		}
	
		type = psql_info->sqlcfg.m_platformtype;
		if(RO_PLATFORM_SIZE <= type)
			type = 0;
		sprintf(typevalue,"%s",sql_ro_platform[type]);
		property_set("ro.fyt.platform",typevalue);

		set_sys_bcsh(psql_info);
		
		ret = property_get("ro.fyt.colorled.input",typevalue);
		if (ret>=0)
			type = !strcmp("true",typevalue);

		psql_info->sqlcfg.ColorLedDir = type;

		if (SIGNATURE_COLOR_LED != psql_info->sqlcfg.ColorLedSig) {
			psql_info->sqlcfg.ColorLedValue = 0x1;
			psql_info->sqlcfg.ColorLedSig = SIGNATURE_COLOR_LED;
		}

	memset(typevalue,0,PROP_VALUE_MAX);
	if(psql_info->sqlcfg.m_McuIC==1)
		property_set("ro.fyt.mcu_type","1");
	else
		property_set("ro.fyt.mcu_type","0");

        munmap_sql_device(&fd_sql,psql_info,sync);
    } else {
		printf("[%s][%d]: mmap error!",__FUNCTION__,__LINE__);
    }
}
//return: 1 vertical platform; 0 common platform
void fyt_detect_vertical_platform()
{
	int result = 0, fd = -1;
	unsigned char ucstatus = '0';
	fd = open("/sys/fytver/is_portrait_screen",O_RDWR);
	if(fd>=0)
	{
		if(read(fd, &ucstatus, 1) > 0) {
			result = ucstatus - '0';
			//D("result=%d,ucstatus=0x%x",result,ucstatus);
		}
		close(fd);
	}
	property_set("ro.build.portrait_screen",result?"true":"false");
	//property_set("qemu.hw.mainkeys",result?"0":"1");
}
void fyt_setRotation(void) {
   int fd;
   int ret;
   char val[4] = { '0',0,0,0 };
   int rotation =0;
   fd = open("/sys/fytver/rotation", O_RDWR);
   if (fd < 0) {
      ERROR("open file failed.\n");
      return;
   }
   ret = read(fd, &val, 4);
   close(fd);
   rotation = atoi(val);
   //if (rotation==90||rotation==270) {
      property_set("ro.sf.hwrotation",val);
   //}
}
#define SQL_DEBUG(fmt,arg...)  printf(fmt,##arg)
#include "sqlactiveui.cpp"
int sqlReadActiveDataUI(char * buf, int size)
{
	int fd =0;
	if(!buf || !size){
		printf("buf size error!\n");
		return -2;
	}
		
	fd = open(SQL_DEVICE,O_RDONLY, 0);
	if(fd>0){
		lseek(fd,UIACTIVEDATA_ADDR,SEEK_SET);
		read(fd,buf,size);
		close(fd);
	}else
	return -1;
	
	return 0;
}
void serialnoget(char *buf)
{
	char * path="/sys/bus/mmc/devices/mmc0:0001/cid";
	int fd;
	//unsigned char buf[33];
	int i;
	
	fd =open(path,O_RDONLY);
	if(fd<0){
		printf("open file failed.\n");
		return ;
	}

	if(read(fd,buf,32)!=32){
		printf("read file failed.\n");
		close(fd);
		return ;	
	}
	
	//property_set("serialno",(char*)buf);
	close(fd);
}
void fyt_set_uiactive()
{
	int fd =0;   
	unsigned char  buff[1028];
	unsigned char serialno[PROP_VALUE_MAX];
	sqlactiveuiinfo getbuf;
	serialno[32]=0;
	serialnoget(serialno);
	//property_get("serialno",serialno);
	serialno[32]=0;
	sqlReadActiveDataUI(buff,UIACTIVESIZE);	
	memcpy(&getbuf,buff,sizeof(getbuf));
	//sscanf(buff,"%08x %s %s",&(getbuf.random),getbuf.serialno,getbuf.activecode);
	getbuf.activecode[32] =0;
	getbuf.serialno[32] =0;
	memset(buff, 0, 1024);
	sprintf(buff,"none %08x s:%s",getbuf.random,serialno);
	getbuf.signature = SIGNATURE_UIACTIVED;
	if(isPlatformActivedUI(&getbuf,serialno))
	{
		sprintf(buff,"none %x",isPlatformActivedUI(&getbuf,serialno));
		property_set("ro.specui.isactived",buff);
			
	}else
	{
		property_set("ro.specui.isactived","actived");	
	}
							
}
void fyt_set_property(){
   int fd;
   int ret;
   char buf[6];
   char val[PROP_VALUE_MAX],val2[PROP_VALUE_MAX];

   fd = open("/sys/fytver/gamma",O_RDWR);
   if (fd<0) {
      ERROR("open file failed.\n");
      return ;
   }
   ret = read(fd,buf,4);
   close(fd);
   if (ret!=4) {
      return;
   }
   sprintf(val,"%d",buf[0]&0xff);
   memset(val2,0,PROP_VALUE_MAX);    
   property_get("sys.gdsp_lut.luminance",val2);
   if (val2[0]==0) {
      property_set("sys.gdsp_lut.luminance",val);
	sprintf(val,"%d",buf[2]&0xff);	
      property_set("sys.gdsp_lut.luminance_def",val);
   }
   sprintf(val,"%d",buf[1]&0xff);
   memset(val2,0,PROP_VALUE_MAX);
   property_get("sys.gdsp_lut.contrast",val2);
   if (val2[0]==0) {
      property_set("sys.gdsp_lut.contrast",val);
	sprintf(val,"%d",buf[3]&0xff);	
      property_set("sys.gdsp_lut.contrast_def",val);
   }
  // load_properties_from_file("/system/app/fyt.prop",NULL);
  // load_properties_from_file("/system/app/config.txt",NULL);
   setPlatform();
   setSqlbootMode();
   //setsubPlatform();
   fyt_serialno();
   fyt_setRotation();
   fyt_detect_vertical_platform();
   fyt_set_uiactive();
}

#endif

