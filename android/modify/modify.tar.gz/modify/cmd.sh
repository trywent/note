#/bin/bash
file=$1
dir=${file%/*}
src="../"$file
dest=$file
echo $dir
echo $src
echo $dest

mkdir -p $dir
cp $src $dest
